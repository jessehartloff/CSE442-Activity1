import sys
import array

if len(sys.argv) > 1:
        fn = sys.argv[1]

        fo = open(fn, "r")
        f = open('output.txt', 'w')
        sentenses = fo.readlines()
        fo.close()

        for inner_list in sentenses:
                isPangram = True
                a = array.array('i',(0 for i in range(0,25)))
        
                for item in inner_list:
                        if ord(item) > 96:
                                if ord(item) < 122:
                                        a[ord(item)-97] = 1

                for character in a:
                        if character == 0:
                                isPangram = False

                if isPangram == True:
                        f.write('true\n')
                else:
                        f.write('false\n')
        f.close()

                
